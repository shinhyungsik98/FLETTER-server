# 깃허브 안올린다
# 안전하게 처리하기 위해서 이렇게 사용한다

class Config :

    # 형식님 AWS
    
    HOST = 'db-1.cnoe24gcojkn.ap-northeast-2.rds.amazonaws.com'
    DATABASE = 'flower_db'
    DB_USER = 'flower_db_user'
    DB_PASSWORD = '5240'

    SALT = 'shteamprojectfletter'

    # AWT credentials 셋팅 
    AWS_ACCESS_KEY = 'AKIAZI2LFVWSKCY4SVEW'
    AWS_SECRET_ACCESS_KEY = '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'

    # AWS Translate 전용
    AWS_TRANSLATE_ACCESS_KEY = 'AKIAZI2LFVWSJOQMHQOX'
    AWS_TRANSLATE_SECRET_ACCESS_KEY = '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'

    # S3 버킷
    S3_BUCKET = 'yhflowerapp'
    S3_URL = 'https://yhflowerapp.s3.ap-northeast-2.amazonaws.com/'

    # GPT 키
    GPT_AI_KEY= 'sk-proj-8kkVymI77kkJmWGq0kkuT3BlbkFJxWmb966u3nsVEFjDW8FU'

    # JWT 관련 변수 셋팅
    JWT_SECRET_KEY = '2whdlqslek,teamfletter'
    # 인증토큰 만료
    JWT_ACCESS_TOKEN_EXPIRES = False
    PROPAGATE_EXCEPTIONS = True


    AWS_TRANSLATE_ACCESS_KEY = 'AKIAZI2LFVWSJOQMHQOX'
    AWS_TRANSLATE_SECRET_ACCESS_KEY = '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'


    




